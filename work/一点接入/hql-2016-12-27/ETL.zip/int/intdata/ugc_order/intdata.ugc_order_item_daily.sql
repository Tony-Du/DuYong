set mapreduce.job.name=intdata.ugc_order_item_daily${EXTRACT_DATE};

set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set mapreduce.map.memory.mb=4096;
set hive.merge.mapredfiles = true;
insert overwrite table intdata.ugc_order_item_daily partition (src_file_day='${EXTRACT_DATE}')
select
orderid,
itemid,
amount,
authtype,
periodunit,
autorelet,
channelid,
expiretime,
extendauthorize,
productid,
producttype,
subtype,
usernum,
validstarttime,
desc,
handler,
main,
quantity,
unitprice,
resource_id,
b.sp_id as cp_id,
from odsdata.ugc_order_item a
left outer join rptdata.dim_charge_product b
on a.productid = b.chrgprod_id and b.dw_delete_flag = 'N'
where source_file_create_day='${EXTRACT_DATE}';