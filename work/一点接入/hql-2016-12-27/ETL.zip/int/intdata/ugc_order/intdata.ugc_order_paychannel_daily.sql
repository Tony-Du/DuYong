set mapreduce.job.name=intdata.ugc_order_paychannel_daily${EXTRACT_DATE};

set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set mapreduce.map.memory.mb=4096;
set hive.merge.mapredfiles = true;
insert overwrite table intdata.ugc_order_paychannel_daily partition (src_file_day='${EXTRACT_DATE}')
select
orderid,
paychannelid,
channeltype,
currency,
payamount
from odsdata.ugc_order_paychannel
where source_file_create_day='${EXTRACT_DATE}';