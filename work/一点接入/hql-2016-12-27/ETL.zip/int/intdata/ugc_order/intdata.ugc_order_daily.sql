set mapreduce.job.name=intdata.ugc_order_daily${EXTRACT_DATE};

set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set mapreduce.map.memory.mb=4096;
set hive.merge.mapredfiles = true;
insert overwrite table intdata.ugc_order_daily partition (src_file_day='${EXTRACT_DATE}')
select
	bb.orderid,
	bb.orderuserid,
	bb.phone_number,
	bb.phone_range,
	bb.createtime,
	bb.orderstatus,
	bb.merchantaccount,
	bb.cancelorderid,
	bb.totalamount,
	bb.servicecode,
	bb.count,
	bb.paytype,
	bb.channelid,
	bb.paymentid,
	bb.appname,
	bb.externalorderid,
	bb.goodsid,
	bb.goodstype,
	bb.resourceid,
	bb.resourcetype,
	case when (bb.goodstype == 'MIGU_PMS' or bb.goodstype == 'MIGU_PROGRAM') then b.sp_id else '' end as cp_id,
	(nvl(c.sub_busi_id, d.sub_busi_id)) as sub_busi_id,
	bb.chn_values[0] as version_id,
	bb.chn_values[1] as chn_id_new,
	bb.chn_values[2] as chn_busi_type,
	f.term_prod_id as term_prod_id,
	g.region_id as city_id,
	substr(bb.chn_values[0], 1, 6) as new_version_id,
	'-998' as user_type,
	'-998' as network_type,
	'-998' as use_type,
	h.company_id as company_id
from (
	select	
		a.orderid,
		a.orderuserid,
		e.user_num as phone_number,
		substr(e.user_num, 1, 7) as phone_range,
		a.createtime,
		a.orderstatus,
		a.merchantaccount,
		a.cancelorderid,
		a.totalamount,
		a.servicecode,
		a.count,
		a.paytype,
		a.channelid,
		a.paymentid,
		a.appname,
		a.externalorderid,
		a.goodsid,
		a.goodstype,
		a.resourceid,
		a.resourcetype,
		split(--version-chn99000-chn_id
		case when chn_source_mask = '0_00000000000' then concat_ws('_', '', '', substr(aa.chn_id_source, 3))
		     when chn_source_mask = '0000_00000000000' then concat_ws('_', '', '', substr(aa.chn_id_source, 6))
		     when chn_source_mask = '0000_000000000000000' then concat_ws('_', '', '', substr(aa.chn_id_source, 6))
		     when chn_source_mask = '0000_00000000-00000-000000000000000' then concat_ws('_', substr(aa.chn_id_source, 6, 8), substr(aa.chn_id_source, 15, 5), substr(aa.chn_id_source, 21))
		     when chn_source_mask in ('00000000000', '000000000000000') then concat_ws('_', '', '', aa.chn_id_source)
		     when chn_source_mask = '00000000-00000-000000000000000' then concat_ws('_', substr(aa.chn_id_source, 1, 8), substr(aa.chn_id_source, 10, 5), substr(aa.chn_id_source, 16))
		     when chn_source_mask like '0\_00000000000\_%' then concat_ws('_', '', '', substr(aa.chn_id_source, 3, 11))
		     when chn_source_mask like '0000\_00000000000\_%' then concat_ws('_', '', '', substr(aa.chn_id_source, 6, 11))    
		      else concat_ws('_', '', '', '')
		end, '_') as chn_values
	from (
		select 
			orderid,
			orderuserid,
			createtime,
			orderstatus,
			merchantaccount,
			cancelorderid,
			totalamount,
			servicecode,
			count,
			paytype,
			channelid,
			paymentid,
			appname,
			externalorderid,
			goodsid,
			goodstype,
			resourceid,
			resourcetype,
			translate(channelid, '1234567899', '000000000') as chn_source_mask
		from odsdata.ugc_order
		where source_file_create_day='${EXTRACT_DATE}'
	) a
	left outer join intdata.userid_usernum e
	on a.order_user_id = e.user_id
) bb
left outer join rptdata.dim_charge_product b
on bb.goodsid = b.chrgprod_id and b.dw_delete_flag = 'N'
left outer join rptdata.to_busi_product_cfg c
on bb.goodsid = c.product_id and c.dw_delete_flag = 'N'
left outer join rptdata.to_new_product_busi_rlt_cfg d
on bb.goodsid = d.new_product_id and d.dw_delete_flag = 'N'
left outer join rptdata.dim_term_prod f
on substr(bb.chn_values[0], 1, 6) = f.term_version_id and f.dw_delete_flag = 'N'
left outer join rptdata.tdim_phone_belong g
on bb.phone_range = g.phone_range and g.dw_delete_flag = 'N'
left outer join rptdata.to_comp_business_info h
on (nvl(c.sub_busi_id, d.sub_busi_id)) = h.sub_busi_id
;
