set mapreduce.job.name=intdata.ugc_payment_daily${EXTRACT_DATE};

set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set mapreduce.map.memory.mb=4096;
set hive.merge.mapredfiles = true;
insert overwrite table intdata.ugc_payment_daily partition (src_file_day='${EXTRACT_DATE}')
select
paymentid,
userid,
mobile,
createtime,
preapprovaltime,
lastupdatetime,
finishtime,
result,
productorderid,
merchantaccount,
thirdtoken,
serviceid,
channelid,
appname      
from odsdata.ugc_payment
where source_file_create_day='${EXTRACT_DATE}';