#!/bin/bash
set -e

if [[ $# -ne 2 ]]; then
echo_and_log "Usage: $FUNCNAME extract_day extract_hour"
return 1
fi
  
extract_day="$1"
extract_hour="$2"
create_time=$(date '+%Y%m%d%H%M%S')
#a_YYYYMMDDHH_CDMP-AuthPlayLog-90101_<重传序号>_<序列号>.dat
file_name="a_${extract_day}${extract_hour}_CDMP-AuthPlayLog-90101"
extract_month="${extract_day:0:6}"

hdfs_path="/user/hive/warehouse/odsdata.db/ugc_auth_play_log/source_file_create_day=${extract_day}/source_file_create_hour=${extract_hour}"

if hdfs dfs -ls ${hdfs_path}/* 1> /dev/null 2>&1; then
    echo "HDFS file ${hdfs_path}/* exists"
else
    echo "HDFS file ${hdfs_path}/* does not exist"
    exit 1
fi

nas_path="/mnt/cdmp/UGC/${extract_month}/${extract_day}/hour"
mkdir -p ${nas_path}
# download from HDFS as a temp_file
# UGC - YYYYMM - YYYYMMDD - order_yyyymmdd_timestamp.dat

hdfs dfs -getmerge ${hdfs_path}/* ${nas_path}/${file_name}.temp

if [[ $? -ne 0 ]]; then
  echo "downloading HDFS file failed"
  exit 1
fi

lines=`wc -l ${nas_path}/${file_name}.temp | awk -F " " {'print $1'}`
bytes=`wc -c ${nas_path}/${file_name}.temp | awk -F " " {'print $1'}`


#a_2016102813_CDMP-AuthPlayLog-90101_00_001.dat
seqnum="00"
if ls ${nas_path}/${file_name}*_001.dat 1> /dev/null 2>&1; then
   seqnum=`ls -l ${nas_path}/${file_name}*_001.dat | tail -1 | awk -F " " {'print $9'} | awk -F "_" {'print $4'}`   
   seqnum=$(($seqnum + 1))
   seqnum="0$seqnum"
   seqnum=${seqnum:(-2)}
fi

mv ${nas_path}/${file_name}.temp ${nas_path}/${file_name}_${seqnum}_001.dat

if [[ $? -ne 0 ]]; then
  echo "moving NAS temp file failed"
  exit 1
fi

#filename|bytes|lines|extract_day|create_time
echo "${file_name}_${seqnum}_001.dat|${bytes}|${lines}|${extract_day}${extract_hour}|${create_time}"> ${nas_path}/${file_name}_${seqnum}.verf
echo "${extract_day} ${extract_hour}" > data_period
