// ORM class for table 'region_flow_daily'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Fri Aug 12 15:23:39 CST 2016
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class region_flow_daily extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  protected ResultSet __cur_result_set;
  private String statis_day;
  public String get_statis_day() {
    return statis_day;
  }
  public void set_statis_day(String statis_day) {
    this.statis_day = statis_day;
  }
  public region_flow_daily with_statis_day(String statis_day) {
    this.statis_day = statis_day;
    return this;
  }
  private String region_code;
  public String get_region_code() {
    return region_code;
  }
  public void set_region_code(String region_code) {
    this.region_code = region_code;
  }
  public region_flow_daily with_region_code(String region_code) {
    this.region_code = region_code;
    return this;
  }
  private String region_name;
  public String get_region_name() {
    return region_name;
  }
  public void set_region_name(String region_name) {
    this.region_name = region_name;
  }
  public region_flow_daily with_region_name(String region_name) {
    this.region_name = region_name;
    return this;
  }
  private Long flow_bytes;
  public Long get_flow_bytes() {
    return flow_bytes;
  }
  public void set_flow_bytes(Long flow_bytes) {
    this.flow_bytes = flow_bytes;
  }
  public region_flow_daily with_flow_bytes(Long flow_bytes) {
    this.flow_bytes = flow_bytes;
    return this;
  }
  private String dw_extract_label;
  public String get_dw_extract_label() {
    return dw_extract_label;
  }
  public void set_dw_extract_label(String dw_extract_label) {
    this.dw_extract_label = dw_extract_label;
  }
  public region_flow_daily with_dw_extract_label(String dw_extract_label) {
    this.dw_extract_label = dw_extract_label;
    return this;
  }
  private java.sql.Timestamp dw_crt_ts;
  public java.sql.Timestamp get_dw_crt_ts() {
    return dw_crt_ts;
  }
  public void set_dw_crt_ts(java.sql.Timestamp dw_crt_ts) {
    this.dw_crt_ts = dw_crt_ts;
  }
  public region_flow_daily with_dw_crt_ts(java.sql.Timestamp dw_crt_ts) {
    this.dw_crt_ts = dw_crt_ts;
    return this;
  }
  private String dw_crt_by;
  public String get_dw_crt_by() {
    return dw_crt_by;
  }
  public void set_dw_crt_by(String dw_crt_by) {
    this.dw_crt_by = dw_crt_by;
  }
  public region_flow_daily with_dw_crt_by(String dw_crt_by) {
    this.dw_crt_by = dw_crt_by;
    return this;
  }
  private java.sql.Timestamp dw_upd_ts;
  public java.sql.Timestamp get_dw_upd_ts() {
    return dw_upd_ts;
  }
  public void set_dw_upd_ts(java.sql.Timestamp dw_upd_ts) {
    this.dw_upd_ts = dw_upd_ts;
  }
  public region_flow_daily with_dw_upd_ts(java.sql.Timestamp dw_upd_ts) {
    this.dw_upd_ts = dw_upd_ts;
    return this;
  }
  private String dw_upd_by;
  public String get_dw_upd_by() {
    return dw_upd_by;
  }
  public void set_dw_upd_by(String dw_upd_by) {
    this.dw_upd_by = dw_upd_by;
  }
  public region_flow_daily with_dw_upd_by(String dw_upd_by) {
    this.dw_upd_by = dw_upd_by;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof region_flow_daily)) {
      return false;
    }
    region_flow_daily that = (region_flow_daily) o;
    boolean equal = true;
    equal = equal && (this.statis_day == null ? that.statis_day == null : this.statis_day.equals(that.statis_day));
    equal = equal && (this.region_code == null ? that.region_code == null : this.region_code.equals(that.region_code));
    equal = equal && (this.region_name == null ? that.region_name == null : this.region_name.equals(that.region_name));
    equal = equal && (this.flow_bytes == null ? that.flow_bytes == null : this.flow_bytes.equals(that.flow_bytes));
    equal = equal && (this.dw_extract_label == null ? that.dw_extract_label == null : this.dw_extract_label.equals(that.dw_extract_label));
    equal = equal && (this.dw_crt_ts == null ? that.dw_crt_ts == null : this.dw_crt_ts.equals(that.dw_crt_ts));
    equal = equal && (this.dw_crt_by == null ? that.dw_crt_by == null : this.dw_crt_by.equals(that.dw_crt_by));
    equal = equal && (this.dw_upd_ts == null ? that.dw_upd_ts == null : this.dw_upd_ts.equals(that.dw_upd_ts));
    equal = equal && (this.dw_upd_by == null ? that.dw_upd_by == null : this.dw_upd_by.equals(that.dw_upd_by));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof region_flow_daily)) {
      return false;
    }
    region_flow_daily that = (region_flow_daily) o;
    boolean equal = true;
    equal = equal && (this.statis_day == null ? that.statis_day == null : this.statis_day.equals(that.statis_day));
    equal = equal && (this.region_code == null ? that.region_code == null : this.region_code.equals(that.region_code));
    equal = equal && (this.region_name == null ? that.region_name == null : this.region_name.equals(that.region_name));
    equal = equal && (this.flow_bytes == null ? that.flow_bytes == null : this.flow_bytes.equals(that.flow_bytes));
    equal = equal && (this.dw_extract_label == null ? that.dw_extract_label == null : this.dw_extract_label.equals(that.dw_extract_label));
    equal = equal && (this.dw_crt_ts == null ? that.dw_crt_ts == null : this.dw_crt_ts.equals(that.dw_crt_ts));
    equal = equal && (this.dw_crt_by == null ? that.dw_crt_by == null : this.dw_crt_by.equals(that.dw_crt_by));
    equal = equal && (this.dw_upd_ts == null ? that.dw_upd_ts == null : this.dw_upd_ts.equals(that.dw_upd_ts));
    equal = equal && (this.dw_upd_by == null ? that.dw_upd_by == null : this.dw_upd_by.equals(that.dw_upd_by));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.statis_day = JdbcWritableBridge.readString(1, __dbResults);
    this.region_code = JdbcWritableBridge.readString(2, __dbResults);
    this.region_name = JdbcWritableBridge.readString(3, __dbResults);
    this.flow_bytes = JdbcWritableBridge.readLong(4, __dbResults);
    this.dw_extract_label = JdbcWritableBridge.readString(5, __dbResults);
    this.dw_crt_ts = JdbcWritableBridge.readTimestamp(6, __dbResults);
    this.dw_crt_by = JdbcWritableBridge.readString(7, __dbResults);
    this.dw_upd_ts = JdbcWritableBridge.readTimestamp(8, __dbResults);
    this.dw_upd_by = JdbcWritableBridge.readString(9, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.statis_day = JdbcWritableBridge.readString(1, __dbResults);
    this.region_code = JdbcWritableBridge.readString(2, __dbResults);
    this.region_name = JdbcWritableBridge.readString(3, __dbResults);
    this.flow_bytes = JdbcWritableBridge.readLong(4, __dbResults);
    this.dw_extract_label = JdbcWritableBridge.readString(5, __dbResults);
    this.dw_crt_ts = JdbcWritableBridge.readTimestamp(6, __dbResults);
    this.dw_crt_by = JdbcWritableBridge.readString(7, __dbResults);
    this.dw_upd_ts = JdbcWritableBridge.readTimestamp(8, __dbResults);
    this.dw_upd_by = JdbcWritableBridge.readString(9, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(statis_day, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(region_code, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(region_name, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeLong(flow_bytes, 4 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeString(dw_extract_label, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(dw_crt_ts, 6 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(dw_crt_by, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(dw_upd_ts, 8 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(dw_upd_by, 9 + __off, 12, __dbStmt);
    return 9;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(statis_day, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(region_code, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(region_name, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeLong(flow_bytes, 4 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeString(dw_extract_label, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(dw_crt_ts, 6 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(dw_crt_by, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(dw_upd_ts, 8 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(dw_upd_by, 9 + __off, 12, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.statis_day = null;
    } else {
    this.statis_day = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.region_code = null;
    } else {
    this.region_code = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.region_name = null;
    } else {
    this.region_name = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.flow_bytes = null;
    } else {
    this.flow_bytes = Long.valueOf(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.dw_extract_label = null;
    } else {
    this.dw_extract_label = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.dw_crt_ts = null;
    } else {
    this.dw_crt_ts = new Timestamp(__dataIn.readLong());
    this.dw_crt_ts.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.dw_crt_by = null;
    } else {
    this.dw_crt_by = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.dw_upd_ts = null;
    } else {
    this.dw_upd_ts = new Timestamp(__dataIn.readLong());
    this.dw_upd_ts.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.dw_upd_by = null;
    } else {
    this.dw_upd_by = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.statis_day) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, statis_day);
    }
    if (null == this.region_code) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, region_code);
    }
    if (null == this.region_name) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, region_name);
    }
    if (null == this.flow_bytes) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.flow_bytes);
    }
    if (null == this.dw_extract_label) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, dw_extract_label);
    }
    if (null == this.dw_crt_ts) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.dw_crt_ts.getTime());
    __dataOut.writeInt(this.dw_crt_ts.getNanos());
    }
    if (null == this.dw_crt_by) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, dw_crt_by);
    }
    if (null == this.dw_upd_ts) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.dw_upd_ts.getTime());
    __dataOut.writeInt(this.dw_upd_ts.getNanos());
    }
    if (null == this.dw_upd_by) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, dw_upd_by);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.statis_day) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, statis_day);
    }
    if (null == this.region_code) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, region_code);
    }
    if (null == this.region_name) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, region_name);
    }
    if (null == this.flow_bytes) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.flow_bytes);
    }
    if (null == this.dw_extract_label) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, dw_extract_label);
    }
    if (null == this.dw_crt_ts) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.dw_crt_ts.getTime());
    __dataOut.writeInt(this.dw_crt_ts.getNanos());
    }
    if (null == this.dw_crt_by) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, dw_crt_by);
    }
    if (null == this.dw_upd_ts) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.dw_upd_ts.getTime());
    __dataOut.writeInt(this.dw_upd_ts.getNanos());
    }
    if (null == this.dw_upd_by) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, dw_upd_by);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(statis_day==null?"null":statis_day, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(region_code==null?"null":region_code, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(region_name==null?"null":region_name, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(flow_bytes==null?"null":"" + flow_bytes, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_extract_label==null?"null":dw_extract_label, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_crt_ts==null?"null":"" + dw_crt_ts, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_crt_by==null?"null":dw_crt_by, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_upd_ts==null?"null":"" + dw_upd_ts, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_upd_by==null?"null":dw_upd_by, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(statis_day==null?"null":statis_day, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(region_code==null?"null":region_code, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(region_name==null?"null":region_name, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(flow_bytes==null?"null":"" + flow_bytes, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_extract_label==null?"null":dw_extract_label, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_crt_ts==null?"null":"" + dw_crt_ts, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_crt_by==null?"null":dw_crt_by, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_upd_ts==null?"null":"" + dw_upd_ts, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dw_upd_by==null?"null":dw_upd_by, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.statis_day = null; } else {
      this.statis_day = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.region_code = null; } else {
      this.region_code = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.region_name = null; } else {
      this.region_name = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.flow_bytes = null; } else {
      this.flow_bytes = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.dw_extract_label = null; } else {
      this.dw_extract_label = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.dw_crt_ts = null; } else {
      this.dw_crt_ts = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.dw_crt_by = null; } else {
      this.dw_crt_by = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.dw_upd_ts = null; } else {
      this.dw_upd_ts = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.dw_upd_by = null; } else {
      this.dw_upd_by = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.statis_day = null; } else {
      this.statis_day = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.region_code = null; } else {
      this.region_code = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.region_name = null; } else {
      this.region_name = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.flow_bytes = null; } else {
      this.flow_bytes = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.dw_extract_label = null; } else {
      this.dw_extract_label = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.dw_crt_ts = null; } else {
      this.dw_crt_ts = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.dw_crt_by = null; } else {
      this.dw_crt_by = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.dw_upd_ts = null; } else {
      this.dw_upd_ts = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.dw_upd_by = null; } else {
      this.dw_upd_by = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    region_flow_daily o = (region_flow_daily) super.clone();
    o.dw_crt_ts = (o.dw_crt_ts != null) ? (java.sql.Timestamp) o.dw_crt_ts.clone() : null;
    o.dw_upd_ts = (o.dw_upd_ts != null) ? (java.sql.Timestamp) o.dw_upd_ts.clone() : null;
    return o;
  }

  public void clone0(region_flow_daily o) throws CloneNotSupportedException {
    o.dw_crt_ts = (o.dw_crt_ts != null) ? (java.sql.Timestamp) o.dw_crt_ts.clone() : null;
    o.dw_upd_ts = (o.dw_upd_ts != null) ? (java.sql.Timestamp) o.dw_upd_ts.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new TreeMap<String, Object>();
    __sqoop$field_map.put("statis_day", this.statis_day);
    __sqoop$field_map.put("region_code", this.region_code);
    __sqoop$field_map.put("region_name", this.region_name);
    __sqoop$field_map.put("flow_bytes", this.flow_bytes);
    __sqoop$field_map.put("dw_extract_label", this.dw_extract_label);
    __sqoop$field_map.put("dw_crt_ts", this.dw_crt_ts);
    __sqoop$field_map.put("dw_crt_by", this.dw_crt_by);
    __sqoop$field_map.put("dw_upd_ts", this.dw_upd_ts);
    __sqoop$field_map.put("dw_upd_by", this.dw_upd_by);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("statis_day", this.statis_day);
    __sqoop$field_map.put("region_code", this.region_code);
    __sqoop$field_map.put("region_name", this.region_name);
    __sqoop$field_map.put("flow_bytes", this.flow_bytes);
    __sqoop$field_map.put("dw_extract_label", this.dw_extract_label);
    __sqoop$field_map.put("dw_crt_ts", this.dw_crt_ts);
    __sqoop$field_map.put("dw_crt_by", this.dw_crt_by);
    __sqoop$field_map.put("dw_upd_ts", this.dw_upd_ts);
    __sqoop$field_map.put("dw_upd_by", this.dw_upd_by);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if ("statis_day".equals(__fieldName)) {
      this.statis_day = (String) __fieldVal;
    }
    else    if ("region_code".equals(__fieldName)) {
      this.region_code = (String) __fieldVal;
    }
    else    if ("region_name".equals(__fieldName)) {
      this.region_name = (String) __fieldVal;
    }
    else    if ("flow_bytes".equals(__fieldName)) {
      this.flow_bytes = (Long) __fieldVal;
    }
    else    if ("dw_extract_label".equals(__fieldName)) {
      this.dw_extract_label = (String) __fieldVal;
    }
    else    if ("dw_crt_ts".equals(__fieldName)) {
      this.dw_crt_ts = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("dw_crt_by".equals(__fieldName)) {
      this.dw_crt_by = (String) __fieldVal;
    }
    else    if ("dw_upd_ts".equals(__fieldName)) {
      this.dw_upd_ts = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("dw_upd_by".equals(__fieldName)) {
      this.dw_upd_by = (String) __fieldVal;
    }
    else {
      throw new RuntimeException("No such field: " + __fieldName);
    }
  }
  public boolean setField0(String __fieldName, Object __fieldVal) {
    if ("statis_day".equals(__fieldName)) {
      this.statis_day = (String) __fieldVal;
      return true;
    }
    else    if ("region_code".equals(__fieldName)) {
      this.region_code = (String) __fieldVal;
      return true;
    }
    else    if ("region_name".equals(__fieldName)) {
      this.region_name = (String) __fieldVal;
      return true;
    }
    else    if ("flow_bytes".equals(__fieldName)) {
      this.flow_bytes = (Long) __fieldVal;
      return true;
    }
    else    if ("dw_extract_label".equals(__fieldName)) {
      this.dw_extract_label = (String) __fieldVal;
      return true;
    }
    else    if ("dw_crt_ts".equals(__fieldName)) {
      this.dw_crt_ts = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("dw_crt_by".equals(__fieldName)) {
      this.dw_crt_by = (String) __fieldVal;
      return true;
    }
    else    if ("dw_upd_ts".equals(__fieldName)) {
      this.dw_upd_ts = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("dw_upd_by".equals(__fieldName)) {
      this.dw_upd_by = (String) __fieldVal;
      return true;
    }
    else {
      return false;    }
  }
}
