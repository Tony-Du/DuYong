
/usr/bin/sqoop export --connect jdbc:mysql://10.200.63.80:3306/bigdata --username root --password root123 --table region_flow_daily --export-dir /user/hive/warehouse/dly.db/region_flow_daily/* --input-fields-terminated-by '\001' --input-null-string '\\N' --input-null-non-string '\\N'
