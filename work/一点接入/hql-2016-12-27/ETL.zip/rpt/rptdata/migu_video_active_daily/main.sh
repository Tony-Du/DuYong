#!/bin/bash


#extract_date=$(date -d "1 days ago" "+%Y%m%d")
extract_date="20160913"

#export JAVA_HOME=/usr/java/jdk1.7.0_67-cloudera
#export PATH=$JAVA_HOME/bin:$SQOOP2_HOME/bin:$PATH
#export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar

mkdir -p /log/bigdata/etl/dly/migu_video_active_daily
/opt/data-integration/kitchen.sh  -file=/bigdata/etl/dly/migu_video_active_daily/main.kjb -param:EXTRACT_DATE=${extract_date} -level=Detail
# >> /log/bigdata/etl/dly/region_flow_daily/${extract_date}.log
